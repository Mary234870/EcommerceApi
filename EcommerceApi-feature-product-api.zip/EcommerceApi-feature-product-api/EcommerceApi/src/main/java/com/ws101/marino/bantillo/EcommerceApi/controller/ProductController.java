package com.ws101.marino.bantillo.EcommerceApi.controller;

import com.ws101.marino.bantillo.EcommerceApi.dto.ProductRequest;
import com.ws101.marino.bantillo.EcommerceApi.model.Product;

import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@RestController
@RequestMapping("/api/products")
public class ProductController {

    private List<Product> products = new ArrayList<>();
    private long nextId = 1;

    // GET all products → 200 OK
    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        return ResponseEntity.ok(products);
    }

    // GET by ID → 200 OK or 404 Not Found
    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
        return products.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst()
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // POST → 201 Created
    @PostMapping
    public ResponseEntity<Product> createProduct(@Valid @RequestBody ProductRequest request) {

    Product product = new Product(); // ✅ create object first

    product.setId(nextId++);
    product.setName(request.getName());
    product.setPrice(request.getPrice());
    product.setCategory(request.getCategory());
    product.setStockQuantity(request.getStockQuantity());

    products.add(product);

    return ResponseEntity.status(201).body(product);
}
    

    // PUT → 200 OK or 404 Not Found
    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product updated) {
        for (Product p : products) {
            if (p.getId().equals(id)) {
                p.setName(updated.getName());
                p.setDescription(updated.getDescription());
                p.setPrice(updated.getPrice());
                p.setCategory(updated.getCategory());
                p.setStockQuantity(updated.getStockQuantity());
                p.setImageUrl(updated.getImageUrl());

                return ResponseEntity.ok(p);
            }
        }
        return ResponseEntity.notFound().build();
    }


    // PUT partially update product 
    @PatchMapping("/{id}")
    public ResponseEntity<Product>partialUpdateProduct(@PathVariable Long id, @RequestBody Product partialProduct) {
        return productService.getProductById(id)
            .map(existing -> {
                if (partialProduct.getName() != null) existing.setName(partialProduct.getName());
                if (partialProduct.getDescription() != null) existing.setDescription(partialProduct.getDescription());
                if (partialProduct.getPrice() != 0) existing.setPrice(partialProduct.getPrice());
                if (partialProduct.getCategory() != null) existing.setCategory(partialProduct.getCategory());
                if (partialProduct.getStockQuantity() != 0) existing.setStockQuantity(partialProduct.getStockQuantity());
                if (partialProduct.getImageUrl() != null) existing.setImageUrl(partialProduct.getImageUrl());

                return productService.updateProduct(id, existing).orElse(null);
            })
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    // DELETE → 204 No Content or 404 Not Found
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable Long id) {
        boolean removed = products.removeIf(p -> p.getId().equals(id));

        if (removed) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
